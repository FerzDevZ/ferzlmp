/*
  To minimize source code changes, we add this source file
  and forward to my_config.h instead.
  See AH_BOTTOM in configure.ac for the rest.
*/
#include "my_config.h"
#include "sys.h"
#define SCCSID
/* #undef LIBC_SCCS */
#define lint
